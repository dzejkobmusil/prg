module com.example.obsahobdelniku {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.obsahobdelniku to javafx.fxml;
    exports com.example.obsahobdelniku;
}