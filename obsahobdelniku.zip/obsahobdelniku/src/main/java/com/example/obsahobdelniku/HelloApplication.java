package com.example.obsahobdelniku;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import java.util.*;

public class HelloApplication extends Application {

    private TextField tfMin = new TextField("2");
    private TextField tfMax = new TextField("10");
    private TextField tfPocet = new TextField("100");
    private TextArea textArea = new TextArea();
    private List<Integer> obsahy = new ArrayList<>();

    @Override
    public void start(Stage primaryStage) {
        // Vstupy
        HBox vstupy = new HBox(10,
                new Label("Min délka:"), tfMin,
                new Label("Max délka:"), tfMax,
                new Label("Počet obdélníků:"), tfPocet
        );

        // Tlačítka
        Button btnTabulka = new Button("Tabulka");
        Button btnGraf = new Button("Graf");
        Button btnKopie = new Button("Kopie");

        HBox tlacitka = new HBox(10, btnTabulka, btnGraf, btnKopie);
        VBox root = new VBox(10, vstupy, tlacitka, textArea);
        root.setPadding(new Insets(10));

        // Akce
        btnTabulka.setOnAction(e -> vypisTabulku());
        btnGraf.setOnAction(e -> zobrazGraf());
        btnKopie.setOnAction(e -> {
            textArea.selectAll();
            textArea.copy();
        });

        primaryStage.setTitle("Obsahy náhodných obdélníků");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }

    private void vypisTabulku() {
        textArea.clear();
        obsahy.clear();

        int min = Integer.parseInt(tfMin.getText());
        int max = Integer.parseInt(tfMax.getText());
        int n = Integer.parseInt(tfPocet.getText());

        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%10s %10s %10s\n", "Strana A", "Strana B", "Obsah"));

        for (int i = 0; i < n; i++) {
            int a = rand.nextInt(max - min + 1) + min;
            int b = rand.nextInt(max - min + 1) + min;
            int obsah = a * b;
            obsahy.add(obsah);
            sb.append(String.format("%10d %10d %10d\n", a, b, obsah));
        }

        textArea.setText(sb.toString());
    }

    private void zobrazGraf() {
        Stage stage = new Stage();
        stage.setTitle("Graf četnosti obsahů");

        Map<Integer, Integer> freqMap = new TreeMap<>();
        for (int o : obsahy) {
            freqMap.put(o, freqMap.getOrDefault(o, 0) + 1);
        }

        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Obsah");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Počet výskytů");

        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        XYChart.Series<String, Number> data = new XYChart.Series<>();
        data.setName("Četnost obsahů");

        for (Map.Entry<Integer, Integer> entry : freqMap.entrySet()) {
            data.getData().add(new XYChart.Data<>(String.valueOf(entry.getKey()), entry.getValue()));
        }

        barChart.getData().add(data);
        stage.setScene(new Scene(barChart, 600, 400));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
