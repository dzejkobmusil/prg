package com.example.penizenauctu;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private TextField amountField = new TextField();
    private TextField interestField = new TextField();
    private TextField yearsField = new TextField();
    private TextArea resultArea = new TextArea();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Peníze na účtu");
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("money.png")));

        GridPane inputGrid = new GridPane();
        inputGrid.setVgap(10);
        inputGrid.setHgap(10);
        inputGrid.setPadding(new Insets(15));

        inputGrid.add(new Label("Vložená částka (Kč):"), 0, 0);
        inputGrid.add(amountField, 1, 0);
        inputGrid.add(new Label("Roční úrok (%):"), 0, 1);
        inputGrid.add(interestField, 1, 1);
        inputGrid.add(new Label("Počet let spoření:"), 0, 2);
        inputGrid.add(yearsField, 1, 2);

        HBox buttons = new HBox(10);
        Button chartButton = new Button("Graf");
        Button tableButton = new Button("Tabulka");
        Button copyButton = new Button("Kopie");
        buttons.getChildren().addAll(chartButton, tableButton, copyButton);

        resultArea.setEditable(false);
        resultArea.setPrefHeight(200);
        VBox layout = new VBox(15, inputGrid, buttons, resultArea);
        layout.setPadding(new Insets(15));
        layout.setAlignment(Pos.CENTER);

        chartButton.setOnAction(e -> showChart());
        tableButton.setOnAction(e -> showTable());
        copyButton.setOnAction(e -> copyToClipboard());

        Scene scene = new Scene(layout, 450, 450);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showChart() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            double interest = Double.parseDouble(interestField.getText()) / 100;
            int years = Integer.parseInt(yearsField.getText());

            Stage chartStage = new Stage();
            chartStage.setTitle("Graf - Peníze na účtu");
            chartStage.getIcons().add(new Image("file:resources/money.png"));

            NumberAxis xAxis = new NumberAxis(0, years, 1);
            NumberAxis yAxis = new NumberAxis();
            xAxis.setLabel("Rok");
            yAxis.setLabel("Stav účtu (Kč)");

            LineChart<Number, Number> chart = new LineChart<>(xAxis, yAxis);
            chart.setTitle("Vývoj úspor");

            XYChart.Series<Number, Number> data = new XYChart.Series<>();
            data.setName("Stav účtu");
            double current = amount;
            for (int i = 0; i <= years; i++) {
                data.getData().add(new XYChart.Data<>(i, current));
                current *= (1 + interest);
            }

            chart.getData().add(data);
            Scene scene = new Scene(chart, 600, 400);
            chartStage.setScene(scene);
            chartStage.show();
        } catch (Exception ex) {
            showAlert("Chyba vstupu", "Zadejte prosím platné číselné hodnoty.");
        }
    }

    private void showTable() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            double interest = Double.parseDouble(interestField.getText()) / 100;
            int years = Integer.parseInt(yearsField.getText());

            StringBuilder sb = new StringBuilder();
            double current = amount;
            for (int i = 0; i <= years; i++) {
                sb.append(String.format("%-4d %15.2f Kč%n", i, current));
                current *= (1 + interest);
            }
            resultArea.setText(sb.toString());
        } catch (Exception ex) {
            showAlert("Chyba vstupu", "Zadejte prosím platné číselné hodnoty.");
        }
    }

    private void copyToClipboard() {
        String text = resultArea.getText();
        if (text != null && !text.isEmpty()) {
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(text);
            clipboard.setContent(content);
        }
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
