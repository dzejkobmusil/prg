package com.example.penizenauctu;

public class HelloController {
    public static void main(String[] args) {
        HelloApplication.launch(HelloApplication.class, args);
    }
}
