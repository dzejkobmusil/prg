module com.example.penizenauctu {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.penizenauctu to javafx.fxml;
    exports com.example.penizenauctu;
}